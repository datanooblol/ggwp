# from folder.file import class
from . import DataModel
from . import EzCheck
from . import EzCohort
from . import EzCustomerMovement
from . import EzRFM