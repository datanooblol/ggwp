from DataModel import DataModel
from EzCustomerMovement import EzCustomerMovement
from EzRFM import EzRMF
from EzCohort import EzCohort

dm = DataModel()
rfm = EzRMF()
cm = EzCustomerMovement()
ch = EzCohort()


if __name__ == "__main__":
   for lib in [dm,rfm,cm,ch]:
       print(f"{lib.prep_data}")