# from folder.file import class
from ggwp.DataModel import DataModel
from ggwp.EzCheck import EzCheck
from ggwp.EzCohort import EzCohort
from ggwp.EzCustomerMovement import EzCustomerMovement
from ggwp.EzRFM import EzRFM